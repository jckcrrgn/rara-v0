using UnityEngine;

public class PlayerController : MonoBehaviour
{
	[Header("Interaction Settings")]
	[SerializeField] private float interactionCheckRadius = 1.5f;
	[SerializeField] private LayerMask interactableLayer = ~0;

	[Header("Bond")]
	[SerializeField] private Bond bond;

	[Header("Held Item")]
	[SerializeField] private Pickupable heldItem = null;

	[Header("Feedback")]
	[SerializeField] private Transform visualRoot;
	[SerializeField] private float shakeDuration = 0.2f;
	[SerializeField] private float shakeMagnitude = 8f;

	[Header("SFX")]
	[SerializeField] private AudioClip struggleSuccessClip;
	[SerializeField] private AudioClip struggleFailClip;
	[SerializeField] private AudioClip bondBreakClip;
	[Tooltip("Grunt of exertion. Plays on every kick attempt regardless of target — " +
		"including suppressed kicks (e.g. prone floor-restraint), so the player " +
		"hears that they tried even when no force was generated.")]
	[SerializeField] private AudioClip kickEffortClip;
	[Tooltip("Default thud when Kick lands on nothing Kickable (or a Kickable rejecting the kick). " +
		"Kickables play their own per-hit SFX, so this only fires for misses.")]
	[SerializeField] private AudioClip kickMissThudClip;

	[Header("Kick")]
	[Tooltip("How long a single kick attempt occupies. The detective's leg goes " +
		"through wind-up, strike, and recovery; she can't initiate another kick " +
		"until that window finishes. Applies even to suppressed (zero-force) " +
		"kicks — she still went through the motion. PLACEHOLDER VALUE: when the " +
		"character model arrives, replace with the actual kick animation length " +
		"(or a kick-active sub-window of it).")]
	[SerializeField] private float kickDuration = 0.5f;

	[Header("Hands")]
	[Tooltip("Child Transform marking where Cassie's bound hands sit. Place it on her " +
	"DORSAL (back) side — the surface that faces UP when prone and DOWN when " +
	"supine — roughly at the small of the back, offset out to the body surface. " +
	"Because it's a child of the player it rides bodyRoll automatically: prone it's " +
	"up in the air, rolled supine it drops to the floor. That geometry is what makes " +
	"'roll onto your back over the tool' the grab posture for hands-behind binding. " +
	"Used by AreHandsOver for the floor-tool pickup gate (#2).")]
	[SerializeField] private Transform handAnchor;

	[Tooltip("Child Transform marking where the kick's physics cast originates. " +
		"Place it at foot height, offset along the body's kick axis (typically " +
		"local +Z, ~0.3-0.5u in front of player center) so the cast starts " +
		"outside the player's own collider. The cast DIRECTION comes from the " +
		"active restraint's GetKickDirection — default is +forward (she kicks " +
		"the way she faces), FloorRestraint overrides for prone/supine. " +
		"If left null, falls back to transform.position, which will probably " +
		"self-hit the player collider on cast.")]
	[SerializeField] private Transform footAnchor;

	[Tooltip("Sphere radius for the kick cast. Wider = more forgiving aim, but " +
		"also more likely to catch off-axis props. ~0.4u feels honest for a foot.")]
	[SerializeField] private float kickCastRadius = 0.4f;

	[Tooltip("Maximum distance along the kick direction the cast reaches. " +
		"Roughly leg-extension distance from the foot anchor.")]
	[SerializeField] private float kickCastDistance = 1.2f;

	[Tooltip("Base impulse magnitude applied to a loose Rigidbody on a 1.0-modifier " +
		"kick. Scaled by the restraint's GetKickModifier — mermaid-kick (0.4) " +
		"applies kickImpulseScale * 0.4 force. Tune via KickTestScaffold scene. " +
		"Day 44: bumped 8→10 after scaffold pass — 8 left the lamp prop " +
		"underpowered on free-kick. Calibration ongoing.")]
	[SerializeField] private float kickImpulseScale = 10f;

	[Tooltip("Layers the kick cast considers. Set to include world props, doors, " +
		"and anything else kickable; exclude the player's own layer to avoid " +
		"self-collision edge cases on top of the explicit self-Rigidbody filter.")]
	[SerializeField] private LayerMask kickCastLayers = ~0;

	[Header("Strike")]
	[Tooltip("Maximum distance from Cassie to the guard at which Strike is valid, " +
		"in metres. During LeanIn the guard walks from the door to " +
		"GuardController.leanInStandoff in front of her — this gate keeps Strike " +
		"honest about that approach: she can't swing a bottle at him while he's " +
		"still on the other side of the room. Set slightly larger than the " +
		"guard's leanInStandoff so the swing opens up during the LAST bit of his " +
		"close-in (the 'swings as he closes' beat). ~1.1–1.3m if leanInStandoff " +
		"is 0.8m; the small buffer is what gives the brief mid-walk strike window.")]
	[SerializeField] private float strikeRange = 1.2f;

	[Header("Restraint")]
	[SerializeField] private RestraintBase currentRestraint;

	// -------------------------------------------------------------------------
	// VS — Phase
	// -------------------------------------------------------------------------

	[Header("VS — Phase")]
	[Tooltip("When true (default), breaking the bond fires OnPlayerFreed and ends " +
		"the level — standard Act 1 behavior. Set false for the Vertical Slice: the " +
		"bond break advances to phase 2 (wrists free, level continues) rather than " +
		"completing. Uncheck this on the VS scene's PlayerController instance.")]
	[SerializeField] private bool freeOnBondBreak = true;

	// -------------------------------------------------------------------------

	public Rigidbody Rb { get; private set; }
	public bool IsGrounded { get; private set; }

	// Read-only accessor for the kick-impulse scale. Exposed so debug/test
	// scaffolds can display the actual impulse magnitude that would be applied
	// on the next kick, rather than hard-coding the default. Production code
	// shouldn't depend on this — it's diagnostic surface only.
	public float KickImpulseScale => kickImpulseScale;

	// Kick state. Set true when a KickCycle is in flight.
	private bool isKicking = false;
	private bool isStriking = false;

	/// <summary>
	/// True if the player is currently committing the body to any action that
	/// should block other body-committing verbs (kick during inch, inch during
	/// flip, flip during kick, etc.). Aggregates the active restraint's busy
	/// state with the kick state.
	///
	/// Restraint coroutines (FloorRestraint's MoveCycle and FlipCycle) check
	/// this before starting a new cycle, so they refuse to start if a kick is
	/// in flight. KickCycle checks this before starting, so it refuses to fire
	/// if a move/flip is in progress.
	///
	/// Steering (A/D heading adjustment) does NOT contribute to IsBusy — it's
	/// aim, not body-committing motion.
	/// </summary>
	public bool IsBusy => isKicking || isStriking || (currentRestraint != null && currentRestraint.IsBusy);

	// -------------------------------------------------------------------------
	// Feign state
	// -------------------------------------------------------------------------
	// True while Cassie is holding the bound-and-helpless pose. Suppresses all
	// player verbs (Struggle, Pick Up, Kick, movement) so the player can't
	// accidentally break the illusion mid-inspection. The guard samples this
	// flag at the inspection moment; holding it through the check-in = pass.
	//
	// Set/cleared only through TryFeign / CancelFeign, which enforce the
	// restraint's CanFeign gate and fire OnFeignChanged. External systems
	// (guard, UI) read IsFeigning; they don't write it directly.
	// -------------------------------------------------------------------------

	private bool isFeigning = false;

	/// <summary>
	/// True while Cassie is holding the bound-and-helpless pose for a guard
	/// inspection. All player verbs are suppressed while this is true. The
	/// guard samples this at the inspection moment — holding the pose through
	/// the check-in is a pass.
	/// </summary>
	public bool IsFeigning => isFeigning;

	/// <summary>
	/// Fires whenever IsFeigning changes. UI subscribes to update the hint
	/// panel; future guard logic can subscribe to trigger inspection outcomes.
	/// Argument is the new value.
	/// </summary>
	public System.Action<bool> OnFeignChanged;

	// -------------------------------------------------------------------------
	// VS Phase State
	// -------------------------------------------------------------------------
	// In the Vertical Slice (freeOnBondBreak = false), breaking the wrist bond
	// does not end the level — it advances to phase 2. wristsFree is set true
	// when EscapeBonds fires in VS mode, marking that Cassie's hands are free.
	//
	// The strike verb gates on this: she can't swing with bound wrists.
	// In Act 1 (freeOnBondBreak = true), wristsFree is also set true by
	// EscapeBonds, but OnPlayerFreed fires immediately (level complete), so
	// the flag is only briefly true before the scene changes — no gameplay impact.
	//
	// ResetBondProgress clears wristsFree so a caught re-bind correctly returns
	// Cassie to phase 1.
	// -------------------------------------------------------------------------

	private bool wristsFree = false;

	/// <summary>
	/// True once the wrist bond has been broken. Set in both VS mode (phase
	/// advance) and Act 1 mode (full freedom). The strike verb requires this
	/// to be true — Cassie can't swing with bound wrists.
	/// </summary>
	public bool WristsFree => wristsFree;

	/// <summary>
	/// Fires when the wrist bond breaks in VS mode (freeOnBondBreak = false).
	/// Does NOT fire in Act 1 mode — OnPlayerFreed fires there instead.
	/// Wire a VS scene coordinator here to respond to phase 1 completion.
	/// </summary>
	public System.Action OnWristsFreed;

	// -------------------------------------------------------------------------

	/// <summary>
	/// True if the bound hands (handAnchor) are within `radius` of a world point.
	/// 3D distance, so it implicitly gates posture: with hands-behind binding the
	/// anchor only reaches floor level when she's rolled supine, so a prone player's
	/// anchor (a body-thickness up) fails against a floor tool with no explicit
	/// belly check. Used by Pickupable's floor-access gate (#2). Returns false (with
	/// a warning) if no handAnchor is wired.
	/// </summary>
	public bool AreHandsOver(Vector3 worldPos, float radius)
	{
		if (handAnchor == null)
		{
			Debug.LogWarning("[PlayerController] AreHandsOver called but no handAnchor " +
				"is assigned — floor-tool pickup will never succeed. Wire the hand anchor.");
			return false;
		}
		return Vector3.Distance(handAnchor.position, worldPos) <= radius;
	}

	// Read-only accessor so other systems (e.g. Kickable orientation gates) can
	// query restraint state without owning a reference.
	public RestraintBase CurrentRestraint => currentRestraint;

	public int StruggleProgress => bond != null ? bond.StruggleProgress : 0;
	public int BondStrength => bond != null ? bond.BondStrength : 1;
	public System.Action OnStruggleProgressChanged;
	public System.Action OnPlayerFreed;

	/// <summary>
	/// Reset bond cut-progress to zero and clear wristsFree. The failure loop
	/// and caught sequence call this on re-bind: the guard re-ties Cassie, so
	/// any partial cut and any freed-wrists state are gone — back to phase 1.
	/// </summary>
	public void ResetBondProgress()
	{
		if (bond != null) bond.ResetProgress();
		wristsFree = false;
	}

	/// <summary>
	/// Fires when a Struggle attempt produces zero or negative bond progress
	/// (e.g. barehanded against a rope, wrong-tool-for-bond combinations). Used
	/// by stuck-player rescue components like BarehandStuckMutter to detect
	/// players who are spamming Struggle without success and need a nudge.
	///
	/// Fires AFTER restraint modifier and environmental-tool aggregation, so
	/// "failed" here means "the full pipeline still produced no progress" —
	/// exactly the condition the player experiences as "I'm pressing Space
	/// and nothing is happening."
	/// </summary>
	public System.Action OnFailedStruggle;

	/// <summary>
	/// Fires on every Struggle attempt that passes the restraint's CanStruggle gate,
	/// regardless of whether it makes bond progress. Notification only — no gameplay
	/// depends on it. The presentation layer subscribes to play the struggle beat.
	/// </summary>
	public System.Action OnStruggleAttempt;

	/// <summary>
	/// Fires when SetRestraint changes the active restraint. UI subscribes to
	/// this so it can re-bind to the new restraint's OnHintsChanged event and
	/// rebuild the hints panel.
	/// </summary>
	public System.Action OnRestraintChanged;

	void Start()
	{
		Rb = GetComponent<Rigidbody>();

		if (bond != null)
		{
			bond.OnProgressChanged += () => OnStruggleProgressChanged?.Invoke();
			bond.OnBroken += EscapeBonds;
		}

		if (currentRestraint == null)
		{
			currentRestraint = GetComponent<RestraintBase>();
		}

		if (currentRestraint != null)
		{
			currentRestraint.OnEnter(this);
			OnRestraintChanged?.Invoke();
		}
		else
		{
			Debug.LogWarning("PlayerController has no RestraintBase. Movement will not work.");
		}
	}

	void Update()
	{
		// Strike CAN interrupt an active mutter. The lean-in beat plays the
		// guard's gloat as a (world-pausing) mutter; the catharsis is Cassie
		// cutting him off mid-sentence by swinging. So H is checked ABOVE
		// the mutter gate: if a strike is currently valid (wrists free + weapon
		// held + guard in LeanIn), pressing H dismisses the mutter and lands
		// the strike in one press. If the strike isn't valid, fall through to
		// the normal gate so H does nothing special during non-strike mutters.
		if (Input.GetKeyDown(KeyCode.H) && CanStrikeNow())
		{
			if (MutterSystem.Instance != null && MutterSystem.Instance.IsActive)
			{
				MutterSystem.Instance.ForceDismissAndClear();
			}
			TryStrike();
			return;
		}

		// While a mutter is showing, world is paused — no movement, no verbs.
		// MutterSystem owns the dismissKey input itself (Space, currently shared
		// with Struggle); gating here keeps Struggle from double-firing on the
		// frame of dismissal.
		if (MutterSystem.Instance != null && MutterSystem.Instance.IsActive)
		{
			return;
		}

		// Suppress Struggle on the frame *after* a mutter dismisses. The dismiss
		// happens in MutterSystem.Update; depending on script execution order,
		// PlayerController.Update could see Space pressed AND IsActive already
		// false in the same frame. WasJustDismissed catches this.
		bool justDismissed = MutterSystem.Instance != null
			&& MutterSystem.Instance.WasJustDismissed;

		// Feign toggle: G key. Available whenever the active restraint supports
		// it (ChairRestraint returns true; others return false by default).
		// Checked BEFORE the IsFeigning gate below so the player can always
		// exit the pose even while it's active.
		if (Input.GetKeyDown(KeyCode.G))
		{
			if (isFeigning)
				CancelFeign();
			else
				TryFeign();
		}

		// While feigning, all other verbs are suppressed — movement, struggle,
		// pick up, kick. The player is holding a posed stillness for the guard.
		if (isFeigning) return;

		if (currentRestraint != null)
		{
			currentRestraint.HandleMovementInput(this);
		}

		if (Input.GetKeyDown(KeyCode.Space) && !justDismissed)
		{
			TryStruggle();
		}

		if (Input.GetKeyDown(KeyCode.E))
		{
			TryPickUp();
		}

		// Kick is its own verb. Effectiveness scaled by restraint
		// (free legs = full force, floor-bound scoot = reduced, floor-bound inch = zero, hogtied = zero).
		if (Input.GetKeyDown(KeyCode.F))
		{
			TryKick();
		}

		// NOTE: Strike (H) is handled ABOVE the mutter gate, near the top of
		// Update — it needs to interrupt the guard's close-gloat mutter (the
		// catharsis is Cassie cutting him off mid-sentence). See CanStrikeNow().
	}

	void TryStruggle()
	{
		if (bond == null)
		{
			Debug.LogWarning("No Bond assigned to player.");
			return;
		}

		if (currentRestraint != null && !currentRestraint.CanStruggle())
		{
			return;
		}

		// Presentation hook: she's committing to a struggle (pass or fail). Fired
		// before progress is computed so even a zero-progress yank still animates.
		OnStruggleAttempt?.Invoke();

		ToolType activeTool = heldItem != null ? heldItem.ToolType : ToolType.BareHands;
		int struggleAmount = bond.GetStruggleProgress(activeTool);

		InteractableBase nearby = FindNearestInteractable();

		if (nearby is EnvironmentalTool envTool && envTool.CanStruggleAgainst(this))
		{
			struggleAmount += bond.GetStruggleProgress(envTool.ToolType);
			envTool.OnStruggle(this);
		}

		if (currentRestraint != null)
		{
			struggleAmount = Mathf.RoundToInt(struggleAmount * currentRestraint.GetStruggleModifier());
		}

		if (struggleAmount <= 0)
		{
			TriggerShake();
			if (AudioManager.Instance != null && struggleFailClip != null)
				AudioManager.Instance.PlaySFX(struggleFailClip, 1f, Random.Range(0.95f, 1.05f));
			OnFailedStruggle?.Invoke();
		}
		else
		{
			if (AudioManager.Instance != null && struggleSuccessClip != null)
				AudioManager.Instance.PlaySFX(struggleSuccessClip, 1f, Random.Range(0.92f, 1.08f));
		}

		bond.ApplyStruggle(struggleAmount);
	}

	/// <summary>
	/// Attempt to enter the Feign pose. Gated on the active restraint's
	/// CanFeign() — only ChairRestraint supports it in v1. Silent no-op if
	/// the restraint doesn't support feigning or if already feigning.
	/// </summary>
	void TryFeign()
	{
		if (isFeigning) return;
		if (currentRestraint == null || !currentRestraint.CanFeign()) return;

		isFeigning = true;
		OnFeignChanged?.Invoke(true);
		Debug.Log("[PlayerController] Feign ENTER.");
	}

	/// <summary>
	/// Exit the Feign pose, restoring all suppressed verbs. Called by the G
	/// key toggle and by the guard system when an inspection window closes
	/// (auto-release once the guard leaves). Safe to call when not feigning.
	/// </summary>
	public void CancelFeign()
	{
		if (!isFeigning) return;

		isFeigning = false;
		OnFeignChanged?.Invoke(false);
		Debug.Log("[PlayerController] Feign EXIT.");
	}

	// Cached reference to the scene's StrikeableGuard. The VS has exactly one
	// guard, and it's a SCRIPTED actor — its LeanIn state is the authority on
	// whether a strike is valid, not its physical distance from Cassie. So we
	// hold a direct reference rather than sweeping for nearby colliders each
	// frame (the old OverlapSphere approach forced the player to physically
	// shuffle next to a guard who never moved toward her). Resolved lazily so
	// it works regardless of script init order. See GetStrikeableGuard.
	private StrikeableGuard strikeableGuard;

	/// <summary>
	/// The scene's StrikeableGuard, cached on first use. Single-guard
	/// assumption — true for the VS. Returns null if none is present.
	/// </summary>
	private StrikeableGuard GetStrikeableGuard()
	{
		if (strikeableGuard == null)
			strikeableGuard = FindFirstObjectByType<StrikeableGuard>();
		return strikeableGuard;
	}

	private CassieStrikeDriver strikeDriver;

	private CassieStrikeDriver GetStrikeDriver()
	{
		if (strikeDriver == null)
			strikeDriver = FindFirstObjectByType<CassieStrikeDriver>();
		return strikeDriver;
	}

	/// <summary>
	/// True if a Strike would currently succeed: Cassie's wrists are free,
	/// she holds a weapon, the scene's StrikeableGuard reports CanBeStruck()
	/// (guard in LeanIn, not yet struck), AND the guard is within strikeRange
	/// of Cassie. Used by Update to decide whether H should interrupt an active
	/// mutter, by TryStrike as the actual gate, and by StrikeHintPrompt to
	/// drive prompt visibility. No side effects, no logging.
	///
	/// Strike validity is the guard's LeanIn STATE plus physical proximity.
	/// The state alone isn't enough: LeanIn fires the instant inspection passes,
	/// but the guard then walks from the door across the room to his standoff
	/// in front of Cassie. Without the proximity gate, she could swing a bottle
	/// at him while he's still mid-walk on the far side of the room — narratively
	/// absurd. With it, the strike opens up during the last bit of his close-in
	/// — the "swings as he closes" beat. His body position is otherwise
	/// presentational, but for the strike specifically, distance matters.
	/// </summary>
	public bool CanStrikeNow()
	{
		if (!wristsFree) return false;
		if (heldItem == null || !heldItem.IsWeapon) return false;
		StrikeableGuard target = GetStrikeableGuard();
		if (target == null || !target.CanBeStruck()) return false;

		// Proximity gate: guard must be within strikeRange. Even when LeanIn
		// has fired, he's walking in from the door — only the last bit of
		// that approach is a valid swing window.
		float dist = Vector3.Distance(transform.position, target.transform.position);
		return dist <= strikeRange;
	}

	/// <summary>
	/// Strike verb entry point. Three gates must all pass:
	///   1. Cassie's wrists are free (wristsFree = true).
	///   2. Player is holding a weapon (heldItem != null and IsWeapon true).
	///   3. The nearest StrikeableGuard reports CanBeStruck() — guard in LeanIn.
	///
	/// All three are bundled in CanStrikeNow(). On a miss, logs which gate
	/// failed (for testing); on a pass, breaks feign and delivers the strike.
	///
	/// Note: Strike is intentionally available while IsFeigning. The whole
	/// point of the turnaround is that Cassie reveals her free hands mid-pose.
	/// Pressing H breaks the feign and swings — the reveal IS the strike.
	/// CancelFeign fires first so verbs re-enable before OnStruck runs.
	/// </summary>
	void TryStrike()
	{
		// Diagnostic logging — split the gate so a miss tells us which half failed.
		if (!wristsFree)
		{
			Debug.Log("[PlayerController] TryStrike: wrists not yet free.");
			return;
		}

		if (heldItem == null || !heldItem.IsWeapon)
		{
			Debug.Log("[PlayerController] TryStrike: no weapon held.");
			return;
		}

		StrikeableGuard target = GetStrikeableGuard();
		if (target == null || !target.CanBeStruck())
		{
			Debug.Log("[PlayerController] TryStrike: no guard in scene or guard not in LeanIn.");
			return;
		}

		// Proximity gate — see CanStrikeNow for rationale.
		float dist = Vector3.Distance(transform.position, target.transform.position);
		if (dist > strikeRange)
		{
			Debug.Log($"[PlayerController] TryStrike: guard out of range " +
				$"(dist={dist:F2} > strikeRange={strikeRange}). He hasn't closed in yet.");
			return;
		}

		// All gates passed. Break feign (the reveal), then deliver the strike.
		if (isFeigning) CancelFeign();

		Debug.Log("[PlayerController] Strike!");
		isStriking = true;

		CassieStrikeDriver driver = GetStrikeDriver();
		if (driver == null)
		{
			// Graybox fallback — no rig in the scene (abstract-testing mode).
			// Land it on the input frame so the beat stays testable without Cassie.
			Debug.Log("[PlayerController] No CassieStrikeDriver — landing strike immediately.");
			target.OnStruck(this);
			isStriking = false;
			return;
		}

		driver.Play(
			onContact: () => target.OnStruck(this),
			onComplete: () => isStriking = false);
	}

	/// <summary>
	/// Kick verb entry point. Delegates to KickCycle coroutine, which owns the
	/// timing of the kick action (wind-up, strike, recovery). Gated on IsBusy AND
	/// IsGrounded: can't kick mid-crawl, mid-flip, mid-kick,
	/// or mid-hop. Cassie's kinetic chain depends on having ground under her —
	/// you can't drive a kick from the air.
	///
	/// Why a coroutine instead of a cooldown timer:
	///   The kick is an action that takes time, not a button with a refractory
	///   period. The coroutine is the timeline. When the character model arrives,
	///   anim triggers, wind-up/strike/recovery SFX, hitbox enable/disable
	///   windows -- all of those slot into the coroutine at the right beats.
	///   Right now the cube has no animation so the coroutine is mostly just
	///   "play sound, apply force, wait." But the shape is correct.
	/// </summary>
	void TryKick()
	{
		if (currentRestraint == null) return;
		if (IsBusy) return;
		if (!IsGrounded) return;

		StartCoroutine(KickCycle());
	}

	/// <summary>
	/// One full kick cycle. Owns its own duration; gates re-entry via isKicking.
	///
	/// - Effort grunt plays on EVERY kick attempt — even suppressed ones — so the
	///   player always hears that they tried. Absence of impact SFX is the cue
	///   that the kick didn't generate force (try scoot, or escape your legs first).
	/// - Force is scaled by the restraint's GetKickModifier (free=1.0, floor-scoot=~0.5,
	///   floor-inch=0, hogtied=0). Zero force = effort grunt only, no thud, no Kickable hit.
	/// - If the nearest interactable is a Kickable that accepts the kick, route force to it.
	/// - Otherwise (no target, wrong target, or position gate failing): play the thud SFX.
	///   This is the "kicking the wall of the van" feedback — emergent, in-character, free.
	///
	/// The duration window applies regardless of outcome. Even a zero-force prone
	/// kick locks the verb for kickDuration -- she still went through the motion.
	/// This makes the prone-vs-scoot lesson clearer: spamming F in prone produces
	/// a deliberate, thwarted cadence of effort grunts, not rapid-fire mashing.
	/// </summary>
	System.Collections.IEnumerator KickCycle()
	{
		isKicking = true;

		// Effort layer: plays on every kick, always. Above the force check so
		// suppressed kicks (e.g. prone floor-restraint, hogtied) still give the
		// player audio feedback that they tried.
		if (AudioManager.Instance != null && kickEffortClip != null)
		{
			AudioManager.Instance.PlaySFX(kickEffortClip, 1f, Random.Range(0.95f, 1.08f));
		}

		float kickForce = currentRestraint.GetKickModifier();

		Debug.Log($"[Kick] Firing. restraint={currentRestraint.GetType().Name}, " +
			$"modifier={kickForce:F2}, scale={kickImpulseScale}, " +
			$"impulse={kickForce * kickImpulseScale:F2}");

		if (kickForce > 0f)
		{
			// Force-generating kick. Do a forward sphere cast from the foot anchor
			// along the restraint's kick direction, partition hits into accepting
			// Kickables vs. loose Rigidbodies, and resolve in priority order.
			//
			// Resolution rules (per Day 43 design):
			//   1. If any Kickable that returns CanBeKicked=true is in the hit set,
			//      route the kick to the NEAREST such Kickable. Other hits ignored.
			//      Preserves all existing Kickable behavior (e.g., L4 door).
			//   2. Else if any non-Kickable Rigidbody is in the hit set, apply an
			//      impulse to each scaled by kickForce. This is the emergent
			//      physics layer — kicks have real presence on world objects.
			//      Notably: Rigidbodies BELONGING to a Kickable that rejected the
			//      kick (e.g., L4 door pivots when out of zone) are excluded, so
			//      off-axis door kicks read as wall-thuds, not partial-feedback.
			//   3. Else miss thud SFX. Existing behavior.
			DoKickCast(kickForce);
		}
		// else: suppressed kick. Effort grunt already played; no thud, no Kickable.

		// Hold the kick state for the full duration regardless of outcome.
		// When animation arrives, replace with anim event hooks for wind-up,
		// strike, and recovery beats.
		yield return new WaitForSeconds(kickDuration);

		isKicking = false;
	}

	/// <summary>
	/// Forward sphere cast for the Kick verb. Encapsulated so KickCycle stays
	/// readable. See KickCycle for the resolution-priority commentary.
	///
	/// Partitioning logic:
	///   - Walk every collider hit by the cast.
	///   - For each, find the owning Kickable (GetComponentInParent) if any.
	///   - If a Kickable owns the collider AND CanBeKicked: candidate accepting Kickable.
	///   - If a Kickable owns the collider AND NOT CanBeKicked: excluded from BOTH
	///     buckets. The rejected Kickable doesn't receive impulse — wall-thud feel
	///     is preserved. This is the off-axis L4 door case.
	///   - If no Kickable owns the collider AND there's a Rigidbody: candidate
	///     loose Rigidbody.
	///   - Player's own Rigidbody filtered out explicitly — even with foot anchor
	///     offset, a cast that overshoots could come back and hit the player from
	///     behind on edge geometry.
	///
	/// Once partitioned, nearest accepting Kickable wins; else all loose Rigidbodies
	/// receive impulse; else miss thud.
	/// </summary>
	private void DoKickCast(float kickForce)
	{
		Vector3 origin = footAnchor != null ? footAnchor.position : transform.position;
		Vector3 direction = currentRestraint.GetKickDirection(this);

		RaycastHit[] hits = Physics.SphereCastAll(
			origin,
			kickCastRadius,
			direction,
			kickCastDistance,
			kickCastLayers,
			QueryTriggerInteraction.Ignore);

		Debug.Log($"[KickCast] origin={origin}, dir={direction}, " +
			$"radius={kickCastRadius}, dist={kickCastDistance}, hits={hits.Length}");
		foreach (RaycastHit h in hits)
		{
			Rigidbody hrb = h.collider != null ? h.collider.attachedRigidbody : null;
			string rbInfo = hrb != null
				? $"rb={hrb.name} mass={hrb.mass} kinematic={hrb.isKinematic}"
				: "rb=<none>";
			Debug.Log($"[KickCast]   hit: {h.collider?.name} ({rbInfo}) dist={h.distance:F2}");
		}

		Kickable nearestAcceptingKickable = null;
		float nearestKickableDist = float.MaxValue;
		System.Collections.Generic.HashSet<Rigidbody> looseRigidbodies =
			new System.Collections.Generic.HashSet<Rigidbody>();
		System.Collections.Generic.HashSet<Rigidbody> kickableOwnedRigidbodies =
			new System.Collections.Generic.HashSet<Rigidbody>();

		foreach (RaycastHit hit in hits)
		{
			if (hit.collider == null) continue;

			Kickable owningKickable = hit.collider.GetComponentInParent<Kickable>();
			Rigidbody hitRb = hit.collider.attachedRigidbody;

			// Always exclude the player's own Rigidbody from impulse application,
			// in case a forward cast wraps back through edge geometry. Belt-and-
			// suspenders alongside the foot anchor offset.
			if (hitRb == Rb) continue;

			if (owningKickable != null)
			{
				if (owningKickable.CanBeKicked(this) && hit.distance < nearestKickableDist)
				{
					nearestAcceptingKickable = owningKickable;
					nearestKickableDist = hit.distance;
				}
				// Track Kickable-owned Rigidbodies so we don't double-route them
				// as loose impulse targets even if they're hit by other colliders
				// in the same cast.
				if (hitRb != null) kickableOwnedRigidbodies.Add(hitRb);
			}
			else if (hitRb != null && !hitRb.isKinematic)
			{
				looseRigidbodies.Add(hitRb);
			}
		}

		// Priority 1: accepting Kickable wins. Route force to it; ignore everything else.
		if (nearestAcceptingKickable != null)
		{
			nearestAcceptingKickable.OnKick(this, kickForce);
			return;
		}

		// Priority 2: loose Rigidbodies receive impulse. Exclude any Rigidbody owned
		// by a rejected Kickable (e.g., L4 door pivots when out of zone) — those
		// stay un-impulsed so the off-axis door read remains "wall thud."
		looseRigidbodies.ExceptWith(kickableOwnedRigidbodies);
		if (looseRigidbodies.Count > 0)
		{
			float impulse = kickForce * kickImpulseScale;
			foreach (Rigidbody rb in looseRigidbodies)
			{
				// Apply at the closest point on the rigidbody's collider rather
				// than at center of mass — kicking a tall lamp at the base vs.
				// at the top produces meaningfully different toppling behavior,
				// and we want that to come out for free from the physics.
				Vector3 applyPoint = rb.ClosestPointOnBounds(origin);
				rb.AddForceAtPosition(direction * impulse, applyPoint, ForceMode.Impulse);
				Debug.Log($"[KickCast] impulse={impulse:F2} → {rb.name} (mass={rb.mass}) at {applyPoint}");
			}
			return;
		}

		// Priority 3: nothing useful in range. Miss thud, same as old behavior.
		if (AudioManager.Instance != null && kickMissThudClip != null)
		{
			AudioManager.Instance.PlaySFX(kickMissThudClip, 1f, Random.Range(0.92f, 1.05f));
		}
	}

	// Shake re-entrancy state. ShakeVisual used to be fired bare on every failed
	// struggle, so mashing Struggle stacked overlapping coroutines: each captured
	// its own "origin" from an already-rotated pose (compounding drift) and each
	// ended by hard-setting localRotation, producing visible snaps. One routine at
	// a time now, with a stable origin and a continuous hand-off between restarts.
	private Coroutine shakeRoutine;
	private Quaternion shakeOrigin;
	private float shakeAngle;

	/// <summary>
	/// Start (or restart) the failed-struggle shake. Safe to call at any rate.
	/// The rest rotation is captured only when no shake is in flight; a restart
	/// inherits the current angle so the motion continues rather than popping.
	/// </summary>
	void TriggerShake()
	{
		if (visualRoot == null) return;

		if (shakeRoutine == null)
		{
			shakeOrigin = visualRoot.localRotation;   // nothing in flight: this IS rest
			shakeAngle = 0f;
		}
		else
		{
			StopCoroutine(shakeRoutine);              // keep origin + current angle
		}

		shakeRoutine = StartCoroutine(ShakeVisual());
	}

	System.Collections.IEnumerator ShakeVisual()
	{
		float direction = Random.value < 0.5f ? -1f : 1f;
		float windupAngle = shakeMagnitude * direction;
		float snapbackAngle = -shakeMagnitude * direction * 1.2f;

		float windupTime = Mathf.Max(0.01f, shakeDuration * 0.6f);
		float snapbackTime = Mathf.Max(0.01f, shakeDuration * 0.4f);

		// Continue from wherever the previous shake left off — never from 0.
		float startAngle = shakeAngle;

		float elapsed = 0f;
		while (elapsed < windupTime)
		{
			float t = elapsed / windupTime;
			float eased = t * t;
			shakeAngle = Mathf.Lerp(startAngle, windupAngle, eased);
			visualRoot.localRotation = shakeOrigin * Quaternion.Euler(0f, shakeAngle, 0f);
			elapsed += Time.deltaTime;
			yield return null;
		}

		elapsed = 0f;
		while (elapsed < snapbackTime)
		{
			float t = elapsed / snapbackTime;
			float eased = 1f - (1f - t) * (1f - t);
			float angle = Mathf.Lerp(windupAngle, snapbackAngle, eased);
			if (t > 0.66f)
			{
				float settleT = (t - 0.66f) / 0.34f;
				angle = Mathf.Lerp(angle, 0f, settleT);
			}
			shakeAngle = angle;
			visualRoot.localRotation = shakeOrigin * Quaternion.Euler(0f, shakeAngle, 0f);
			elapsed += Time.deltaTime;
			yield return null;
		}

		shakeAngle = 0f;
		visualRoot.localRotation = shakeOrigin;
		shakeRoutine = null;
	}

	void TryPickUp()
	{
		if (heldItem != null)
		{
			Debug.Log($"Already holding {heldItem.ItemName}.");
			return;
		}

		InteractableBase nearby = FindNearestInteractable();
		if (nearby == null)
		{
			Debug.Log("Nothing to interact with here.");
			return;
		}

		// OnPickUp is the E-key dispatch hook on InteractableBase, not literally
		// "picking up." Pickupable subclasses use it for the held-item handoff
		// (player.HoldItem + SetActive(false) on world version). Non-Pickupable
		// Interactables (Drawer, future doors, etc.) can override OnPickUp to
		// mean their own E-key verb -- a back-facing drawer opens, a lever
		// flips, etc. Each subclass decides what E means in its context.
		nearby.OnPickUp(this);
	}

	public void HoldItem(Pickupable item)
	{
		heldItem = item;
		Debug.Log($"Picked up {item.ItemName}.");
	}

	public Pickupable GetHeldItem()
	{
		return heldItem;
	}

	/// <summary>
	/// Forcibly remove the player's held item without restoring it to the world.
	/// Used by FailureLoopController to model the guard confiscating a tool
	/// (e.g. the L6 pen) when re-binding Cassie. Distinct from Pickupable's
	/// DropFromPlayer flow, which re-enables the world version — confiscation
	/// is one-way: the item is gone.
	///
	/// The Pickupable's GameObject was already SetActive(false) on pickup
	/// (see Pickupable.OnPickUp); we defensively re-disable it here in case
	/// some future code path put it back. We do NOT Destroy it — same
	/// rationale as ChairRestraint's broken-chair handling: scene-rooted,
	/// inactive, available for debug inspection without scene reload.
	///
	/// No-op if nothing is held.
	/// </summary>
	public void ConfiscateHeldItem()
	{
		if (heldItem == null) return;
		Debug.Log($"[PlayerController] Confiscating held item: {heldItem.ItemName}.");
		heldItem.HideHeldVisual();
		if (heldItem.gameObject.activeSelf) heldItem.gameObject.SetActive(false);
		heldItem = null;
	}

	/// <summary>
	/// Remove the player's held item and return it to the world where it was
	/// picked up — the non-destructive counterpart to ConfiscateHeldItem. Used
	/// when the guard disarms Cassie on a caught re-bind: he takes the weapon out
	/// of her hands, but it stays in the room (back on the table it came from), so
	/// the slice remains solvable — she re-frees her wrists, re-acquires it, and
	/// tries the turnaround again.
	///
	/// Pickupable.OnPickUp only SetActive(false)'s the item in place — it never
	/// moves the transform — so DropFromPlayer's SetActive(true) returns it to the
	/// exact pickup spot with no cached home position. DropFromPlayer does NOT
	/// clear heldItem, so we null it here; otherwise she'd "hold" a bottle that's
	/// simultaneously sitting on the table.
	///
	/// No-op if nothing is held.
	/// </summary>
	public void ReturnHeldItemToWorld()
	{
		if (heldItem == null) return;
		Debug.Log($"[PlayerController] Returning held item to world: {heldItem.ItemName}.");
		heldItem.DropFromPlayer();
		heldItem = null;
	}

	/// The guard takes what's in her hands. Whether it comes back is the item's
	/// call — see Pickupable.returnedOnDisarm.
	public void DisarmHeldItem()
	{
		if (heldItem == null) return;
		if (heldItem.ReturnedOnDisarm) ReturnHeldItemToWorld();
		else ConfiscateHeldItem();
	}

	InteractableBase FindNearestInteractable()
	{
		// Broadphase: gather everything within the global interaction sweep.
		// interactionCheckRadius is a generous upper bound; the per-instance
		// filter below is what actually gates which objects accept interaction.
		Collider[] hits = Physics.OverlapSphere(transform.position, interactionCheckRadius, interactableLayer);

		InteractableBase nearest = null;
		float nearestDist = float.MaxValue;

		foreach (Collider hit in hits)
		{
			InteractableBase interactable = hit.GetComponent<InteractableBase>();
			if (interactable == null) continue;
			if (!interactable.gameObject.activeInHierarchy) continue;

			float dist = Vector3.Distance(transform.position, hit.transform.position);

			// Per-instance range filter: each interactable declares its own
			// reach distance via InteractionRange. The drawer's bound-hands
			// verb wants a short range (Cassie has to be close, simulating
			// limited reach behind her back). A pen on a table wants a
			// normal pickup range. The global interactionCheckRadius is the
			// broadphase upper bound; this is the per-object tuning knob.
			if (dist > interactable.InteractionRange) continue;

			if (dist < nearestDist)
			{
				nearest = interactable;
				nearestDist = dist;
			}
		}

		return nearest;
	}

	void EscapeBonds()
	{
		// Mark wrists free in both paths — the strike gate always checks this.
		wristsFree = true;

		if (!freeOnBondBreak)
		{
			// VS two-phase mode: wrists free, but the level is not over.
			// Fire OnWristsFreed for the VS coordinator; do NOT fire OnPlayerFreed.
			// The bond break SFX still plays — she earned it.
			if (AudioManager.Instance != null && bondBreakClip != null)
				AudioManager.Instance.PlaySFX(bondBreakClip, 1f, 1f);
			OnWristsFreed?.Invoke();
			Debug.Log("[PlayerController] Wrists free — phase 1 complete. Level continues.");
			return;
		}

		// Default: bond break = full freedom = level complete.
		Debug.Log("FREE OF BONDS!");
		if (AudioManager.Instance != null && bondBreakClip != null)
			AudioManager.Instance.PlaySFX(bondBreakClip, 1f, 1f);
		OnPlayerFreed?.Invoke();
	}

	public void SetRestraint(RestraintBase newRestraint)
	{
		if (currentRestraint != null) currentRestraint.OnExit(this);
		currentRestraint = newRestraint;
		if (currentRestraint != null) currentRestraint.OnEnter(this);
		OnRestraintChanged?.Invoke();
	}

	void OnCollisionStay(Collision collision)
	{
		foreach (ContactPoint contact in collision.contacts)
		{
			if (contact.point.y < transform.position.y)
			{
				IsGrounded = true;
				return;
			}
		}
	}

	void OnCollisionExit(Collision collision)
	{
		IsGrounded = false;
	}
}
